#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;



// [[Rcpp::export]]
arma::mat PD(Rcpp::CharacterMatrix seqmat)
{
int s=seqmat.nrow();
int len=seqmat.ncol();
int num;
arma::mat mat(s,s,arma::fill::zeros);
for(int i=0;i<s-1;i++)
{
for(int j=i+1;j<s;j++)
{
num=0;
for(int k=0;k<len;k++)
{
if(seqmat(i,k)!=seqmat(j,k))
{
num=num+1;
}//if
}//k
mat(i,j)=mat(j,i)=(double) num/len;
}//j
}//i
return mat;
}



// [[Rcpp::export]]
arma::mat sps_PD(Rcpp::StringVector spsname,Rcpp::StringVector seqname,Rcpp::NumericMatrix seqdistmat)
{
int s=spsname.size();
int len=seqname.size();
int num;
arma::mat mat(s,s,arma::fill::zeros);
std::vector<int> id1;
std::vector<int> id2;
std::vector<double> nv;
double min;
for(int i=0;i<s-1;i++)
{
for(int j=i+1;j<s;j++)
{
for(int k=0;k<len;k++)
{
if(seqname[k]==spsname[i])
{
id1.push_back(k);
}//if
if(seqname[k]==spsname[j])
{
id2.push_back(k);
}//if
}//k
for(int k=0;k<id1.size();k++)
{
for(int l=0;l<id2.size();l++)
{
nv.push_back(seqdistmat(id1[k],id2[l]));
}//l
}//k
min=*min_element(nv.begin(),nv.end());
mat(i,j)=mat(j,i)=min;
nv.clear();//require a new vector!!!
id1.clear();//require a new vector!!!
id2.clear();//require a new vector!!!
}//j
}//i
return mat;
}
